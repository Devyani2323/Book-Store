<html>
<style>
body
{
background-color:pink;
}

h1{
text-align:center;
color:red;
font-size:40px;
font-family:Britannic;

width:50%;
background-color:grey;
margin-right:auto;
margin-left:auto;
}

imgc{
position:absolute;
        top:10;
right:70;
}

imgl{
position:absolute;
        top:10;
right:10;
}

img1{
position:absolute;
        top:160;
right:400;
}
nav {
width:28%;
float:right;
}

footer {
color:yellow;
background-color:black;
height:70px;
position:absolute;
bottom:0;
       
width: 1355px;
}
nav ul{
list-style-type:none;
}

nav li{
float:left;
margin-right:10px;
}
</style>
<head>
<title> Thank You </title>
</head>

<body>
<center><h1>Thank you For Shopping...</h1></center>

<center><h2> Your product will be <br>Delivered after 5 days to your address...</h2>

<imgc> 
<img src="images/sc.png" width="40px" height="40px" />
<a href="payment.php"><br>My Cart</a>
</imgc>


<imgl> 
<img src="images/n.png" width="40px" height="40px" />
<a href="clearcartlogout.php"><br>Log out</a>
</imgl>


<img1> 
<img src="images/ty.png" width="600px" height="400px"  />
</img1>
</center>



<footer>
<small>
&#160;&#160;By using the Web site, you confirm that you have read, understood, and 
agreed to be bound by the Terms and Conditions
<br>&#160;&#160;OnlineBooks Inc. All Rights Reserved <br>&#160;&#160;Copyright &copy; 2002-2015 Niket Raj</small>
<nav>
<ul>
<li><a href="home.html">Home</a></li>    
<li><a href="about.html">About</a></li>
<li><a href="contact.html">Contact us</a></li>
<li><a href="signup.html">Sign up</a></li>
<li><a href="signin.html">My Account</a></li>
</ul>
</nav>
</footer>
</p>


</body>
</html>