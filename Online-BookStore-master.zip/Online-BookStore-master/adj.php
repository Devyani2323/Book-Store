


<form action="searchresults.php" method="post">
<input  type ="radio" name="title" value="t"  ></form>

