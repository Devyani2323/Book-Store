# Online-BookStore
Bookstore Website for selling books using HTML,CSS and PHP.

Online Book store is an online web application where the customer can purchase books online. This application also enables vendor to setup online book store, customers to browse through the books, and a system administrator to approve and reject requests for new books and maintain lists of book categories.
http://localhost/bookstore/home.html
