DELETE FROM `online_book_store`.`payment` WHERE `payment`.`basket_id` = '';
DELETE FROM `online_book_store`.`payment` WHERE `payment`.`basket_id` = 'BB001';
DELETE FROM `online_book_store`.`payment` WHERE `payment`.`basket_id` = 'BB004';
DELETE FROM `online_book_store`.`payment` WHERE `payment`.`basket_id` = 'BB005';
DELETE FROM `online_book_store`.`payment` WHERE `payment`.`basket_id` = 'BB008';
DELETE FROM `online_book_store`.`payment` WHERE `payment`.`basket_id` = 'BB010';
DELETE FROM `online_book_store`.`payment` WHERE `payment`.`basket_id` = 'BB011';
DELETE FROM `online_book_store`.`payment` WHERE `payment`.`basket_id` = 'BB019';